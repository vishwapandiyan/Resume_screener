"""
RAG API (separate module)
- Efficient ingestion into Chroma per workspace collection
- Hybrid retrieval (semantic + keyword) with query expansion via LLaMA
- Conversational memory using LangChain ConversationBufferMemory
"""

from __future__ import annotations

from flask import Blueprint, request, jsonify
import re
from typing import Dict, List, Any, Tuple
import numpy as np
import chromadb

# Optional LangChain memory (lightweight usage)
try:
    from langchain.memory import ChatMessageHistory, ConversationBufferMemory
    from langchain.chains import ConversationalRetrievalChain  # noqa: F401 (documented import)
    import chainlit as cl  # noqa: F401 (documented import)
except Exception:  # pragma: no cover
    ChatMessageHistory = None
    ConversationBufferMemory = None

rag_bp = Blueprint('rag', __name__, url_prefix='/rag')

# Injected clients/models
_llama_client = None
_chroma_client: chromadb.PersistentClient | None = None
_sentence_model = None

# In-memory conversation store: {(workspace_id, chat_id): ConversationBufferMemory}
_memories: Dict[Tuple[str, str], Any] = {}


def init_rag_blueprint(app, llama_client, chroma_client, sentence_model):
    global _llama_client, _chroma_client, _sentence_model
    _llama_client = llama_client
    _chroma_client = chroma_client
    _sentence_model = sentence_model
    app.register_blueprint(rag_bp)


def _collection_name(workspace_id: str) -> str:
    return f"resumes_{workspace_id}"


def _get_or_create_collection(name: str):
    assert _chroma_client is not None, "Chroma client not initialized"
    try:
        return _chroma_client.get_or_create_collection(name=name)
    except Exception:
        return _chroma_client.create_collection(name=name)


def _chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
    if not text:
        return []
    chunks: List[str] = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + chunk_size, length)
        chunk = text[start:end]
        chunks.append(chunk)
        if end == length:
            break
        start = max(end - overlap, 0)
    return chunks


def _embed_texts(texts: List[str]) -> List[List[float]]:
    assert _sentence_model is not None, "Sentence model not loaded"
    if not texts:
        return []
    embs = _sentence_model.encode(texts)
    return [e.tolist() if hasattr(e, 'tolist') else list(e) for e in embs]


def _expand_query(query: str) -> List[str]:
    expansions: List[str] = []
    try:
        if _llama_client:
            prompt = (
                "Generate 3 short semantic query expansions (comma-separated) for searching a resume.\n"
                f"Query: {query}\nReturn only expansions separated by commas."
            )
            completion = _llama_client.chat.completions.create(
                model="meta/llama3-70b-instruct",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=150,
                stream=False,
            )
            text = completion.choices[0].message.content.strip()
            expansions = [q.strip() for q in text.split(',') if q.strip()]
    except Exception:
        expansions = []

    if not expansions:
        # Simple keyword-based expansion fallback
        words = re.findall(r"[A-Za-z0-9_#\+\.\-]+", query)
        key = " ".join(words[:6])
        expansions = [query, key]
    else:
        expansions = [query] + expansions
    return expansions[:4]


def _keyword_score(text: str, query_terms: List[str]) -> float:
    text_low = text.lower()
    score = 0
    for t in query_terms:
        if t and t in text_low:
            score += 1
    return float(score)


@rag_bp.route('/ingest', methods=['POST'])
def rag_ingest():
    data = request.get_json() or {}
    workspace_id = data.get('workspace_id', '').strip()
    resumes: List[Dict[str, Any]] = data.get('resumes', [])
    if not workspace_id or not resumes:
        return jsonify({'error': 'workspace_id and resumes are required'}), 400

    col = _get_or_create_collection(_collection_name(workspace_id))

    total_chunks = 0
    try:
        ids: List[str] = []
        docs: List[str] = []
        metas: List[Dict[str, Any]] = []

        for r in resumes:
            rid = r.get('id') or r.get('resume_id')
            text = r.get('text', '')
            if not rid or not text:
                continue
            chunks = _chunk_text(text)
            for idx, ch in enumerate(chunks):
                ids.append(f"{rid}::c{idx}")
                docs.append(ch)
                metas.append({
                    'resume_id': rid,
                    'candidate': r.get('candidate', ''),
                    'email': r.get('email', ''),
                    'skills': r.get('skills', []),
                    'experience': r.get('experience', ''),
                    'rank': r.get('rank', 0),
                    'chunk_idx': idx,
                })
            total_chunks += len(chunks)

        embeddings = _embed_texts(docs)
        if ids:
            col.add(ids=ids, documents=docs, metadatas=metas, embeddings=embeddings)

        return jsonify({'success': True, 'workspace_id': workspace_id, 'chunks_added': total_chunks})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@rag_bp.route('/suggest', methods=['POST'])
def rag_suggest():
    data = request.get_json() or {}
    workspace_id = data.get('workspace_id', '').strip()
    resume_id = data.get('resume_id', '').strip()
    if not workspace_id or not resume_id:
        return jsonify({'error': 'workspace_id and resume_id are required'}), 400

    questions: List[str] = []
    try:
        if _llama_client:
            prompt = (
                "Given a resume, propose 4 short, helpful questions for an HR reviewer.\n"
                "Focus on: strengths, key projects, role fit, and experience depth.\n"
                "Return as a comma-separated list only."
            )
            completion = _llama_client.chat.completions.create(
                model="meta/llama3-70b-instruct",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=120,
                stream=False,
            )
            text = completion.choices[0].message.content.strip()
            questions = [q.strip() for q in text.split(',') if q.strip()]
    except Exception:
        questions = []

    if not questions:
        questions = [
            "Summarize the candidate's strengths for this role",
            "What key projects demonstrate relevant experience?",
            "How well does the candidate match the job description?",
            "Any potential gaps or risks to note?",
        ]

    return jsonify({'success': True, 'workspace_id': workspace_id, 'resume_id': resume_id, 'questions': questions[:4]})


@rag_bp.route('/query', methods=['POST'])
def rag_query():
    data = request.get_json() or {}
    workspace_id = data.get('workspace_id', '').strip()
    message = data.get('message', '').strip()
    resume_id = data.get('resume_id', '').strip() or None
    k = int(data.get('k', 5))
    chat_id = (data.get('chat_id') or (resume_id or 'global')).strip()

    if not workspace_id or not message:
        return jsonify({'error': 'workspace_id and message are required'}), 400

    col = _get_or_create_collection(_collection_name(workspace_id))

    # Memory
    mem_key = (workspace_id, chat_id)
    memory = None
    if ConversationBufferMemory and ChatMessageHistory:
        memory = _memories.get(mem_key)
        if memory is None:
            memory = ConversationBufferMemory(memory_key='history', return_messages=True)
            _memories[mem_key] = memory
        # Save user message
        try:
            memory.chat_memory.add_user_message(message)
        except Exception:
            pass

    # Query expansion
    expansions = _expand_query(message)
    query_terms = [t.lower() for t in re.findall(r"[A-Za-z0-9_#\+\.\-]+", " ".join(expansions))]

    # Vector retrieval for each expansion, optionally constrained to resume_id
    results: List[Tuple[str, str, Dict[str, Any], float]] = []  # (id, doc, meta, score)

    try:
        for q in expansions:
            emb = _embed_texts([q])[0]
            where = {'resume_id': resume_id} if resume_id else None
            qr = col.query(query_embeddings=[emb], n_results=k, where=where)

            docs = qr.get('documents', [[]])[0]
            metas = qr.get('metadatas', [[]])[0]
            ids = qr.get('ids', [[]])[0]
            dists = qr.get('distances', [[]])[0] if 'distances' in qr else [0.0] * len(docs)

            for i in range(len(docs)):
                doc = docs[i]
                meta = metas[i] if i < len(metas) else {}
                chunk_id = ids[i] if i < len(ids) else ''
                dist = float(dists[i]) if i < len(dists) else 0.0
                # Convert distance to similarity (lower dist -> higher sim)
                sim = 1.0 / (1.0 + dist)
                keyscore = _keyword_score(doc.lower(), query_terms)
                hybrid = 0.7 * sim + 0.3 * (keyscore / max(1.0, len(query_terms)))
                results.append((chunk_id, doc, meta, hybrid))
    except Exception as e:
        return jsonify({'error': f'retrieval_failed: {e}'}), 500

    # Deduplicate by chunk id, keep best score
    best: Dict[str, Tuple[str, Dict[str, Any], float]] = {}
    for cid, doc, meta, score in results:
        prev = best.get(cid)
        if prev is None or score > prev[2]:
            best[cid] = (doc, meta, score)

    # Top-K by score
    ranked = sorted(best.items(), key=lambda x: x[1][2], reverse=True)[:k]
    contexts = [it[1][0] for it in ranked]
    snippets = [
        {
            'id': cid,
            'text': it[1][0],
            'score': float(round(float(it[1][2]), 4)),
            'metadata': it[1][1],
        }
        for cid, it in ranked
    ]

    # Synthesize answer
    answer = None
    try:
        if _llama_client and contexts:
            prompt = (
                "You are an HR assistant. Answer the user's question about the candidate using only the provided context.\n"
                "Be concise and directly relevant to the question. If not enough info, say what is missing.\n\n"
                f"Question: {message}\n\nContext:\n" + "\n---\n".join(contexts[:5])
            )
            completion = _llama_client.chat.completions.create(
                model="meta/llama3-70b-instruct",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=400,
                stream=False,
            )
            answer = completion.choices[0].message.content.strip()
    except Exception:
        answer = None

    if not answer:
        # Simple fallback answer
        joined = contexts[0][:600] if contexts else ''
        answer = f"Based on retrieved context, here are relevant details: {joined}" if joined else "No sufficient information retrieved."

    # Save AI response to memory
    if memory is not None:
        try:
            memory.chat_memory.add_ai_message(answer)
        except Exception:
            pass

    return jsonify({
        'success': True,
        'workspace_id': workspace_id,
        'resume_id': resume_id,
        'chat_id': chat_id,
        'answer': answer,
        'snippets': snippets,
    })


